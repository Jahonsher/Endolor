====================================================
  EndoLor — Webspace / Domain ga joylashtirish
====================================================

1) FAYLLARNI YUKLASH
   Ushbu papkadagi BARCHA fayllarni (jumladan .htaccess, images/, assets/)
   webspace hosting'ingizning root papkasiga yuklang. Odatda:
      /public_html/     yoki
      /www/             yoki
      /htdocs/

   Domain: endolor.uz
   FTP/File Manager orqali yuklashingiz mumkin.

2) APACHE HOSTING (cPanel, shared hosting - eng ko'p tarqalgan)
   ✓ Hech qanday qo'shimcha sozlash kerak emas.
   ✓ .htaccess fayli avtomatik ishlaydi (React Router uchun).
   ✓ mod_rewrite yoqilgan bo'lishi shart (99% shared hosting'da yoqilgan).

3) NGINX HOSTING (VPS/dedicated server)
   Server config'ga quyidagini qo'shing:

   server {
       listen 80;
       server_name endolor.uz www.endolor.uz;
       root /var/www/endolor;
       index index.html;

       location / {
           try_files $uri $uri/ /index.html;
       }

       location ~* \.(js|css|png|jpg|jpeg|gif|webp|svg|ico|woff2)$ {
           expires 1y;
           add_header Cache-Control "public, immutable";
       }

       gzip on;
       gzip_types text/plain text/css application/json application/javascript
                  text/xml application/xml image/svg+xml;
   }

4) DOMAIN + SSL
   - endolor.uz domain DNS A yozuvi hosting IP'ga yo'naltirilishi kerak
   - SSL sertifikat (Let's Encrypt) o'rnating (cPanel'da bir tugma)

5) TEKSHIRISH
   Yuklab bo'lgach, brauzerdan oching:
      https://endolor.uz/
      https://endolor.uz/services   (React router ishlashi kerak)
      https://endolor.uz/about
      https://endolor.uz/videos
      https://endolor.uz/contact

   Agar /services sahifasi 404 chiqarsa — .htaccess yuklanmagan yoki
   mod_rewrite o'chirilgan (hosting'ga murojaat qiling).

6) TELEGRAM BOT
   Formalar Telegram'ga xabar yuboradi. Bot token va chat ID
   src/utils/sendToTelegram.js da yozilgan va build'ga o'rnatilgan.
   Agar o'zgartirmoqchi bo'lsangiz — qayta build qiling.

====================================================
  Fayllar tarkibi:
====================================================
  index.html          — asosiy sahifa
  .htaccess           — Apache konfiguratsiya (SPA router uchun)
  assets/             — CSS va JS (siqilgan)
  images/             — Barcha rasmlar (hero, about, services, carousel)
  logo.png            — Klinika logotipi
  logo-white.webp     — Oq varianti (footer uchun)
  favicon.svg         — Brauzer ikonkasi
====================================================
